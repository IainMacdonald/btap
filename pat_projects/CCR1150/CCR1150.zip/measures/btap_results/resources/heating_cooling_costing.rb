class BTAPCosting
  def heating_costing(model, prototype_creator)
    puts "test heating"
  end
end